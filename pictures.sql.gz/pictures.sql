-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 31 2020 г., 14:42
-- Версия сервера: 5.7.29
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson5`
--

-- --------------------------------------------------------

--
-- Структура таблицы `pictures`
--

CREATE TABLE `pictures` (
  `id` int(11) NOT NULL,
  `name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `pictures`
--

INSERT INTO `pictures` (`id`, `name`, `path`, `size`, `views`) VALUES
(40, 'p1.jpg', 'php/pictures_big', 337140, 0),
(41, 'p10.jpg', 'php/pictures_big', 299380, 0),
(42, 'p11.jpg', 'php/pictures_big', 121945, 0),
(43, 'p12.jpg', 'php/pictures_big', 184533, 0),
(44, 'p13.jpg', 'php/pictures_big', 241397, 0),
(45, 'p14.jpg', 'php/pictures_big', 155035, 0),
(46, 'p15.jpg', 'php/pictures_big', 339623, 0),
(47, 'p16.jpg', 'php/pictures_big', 177563, 0),
(48, 'p17.jpg', 'php/pictures_big', 204444, 0),
(49, 'p18.jpg', 'php/pictures_big', 87326, 0),
(50, 'p2.jpg', 'php/pictures_big', 320857, 0),
(51, 'p3.jpg', 'php/pictures_big', 294972, 0),
(52, 'p4.jpg', 'php/pictures_big', 244504, 0),
(53, 'p5.jpg', 'php/pictures_big', 341127, 0),
(54, 'p6.jpg', 'php/pictures_big', 288039, 0),
(55, 'p7.jpg', 'php/pictures_big', 315151, 0),
(56, 'p8.jpg', 'php/pictures_big', 255521, 0),
(57, 'p9.jpg', 'php/pictures_big', 276632, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `pictures`
--
ALTER TABLE `pictures`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `pictures`
--
ALTER TABLE `pictures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
